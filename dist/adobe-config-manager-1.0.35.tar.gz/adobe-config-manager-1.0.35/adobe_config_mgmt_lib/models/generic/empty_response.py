from pydantic import BaseModel


class EmptyResponse(BaseModel):
    """
    Wrapper for empty response
    """
