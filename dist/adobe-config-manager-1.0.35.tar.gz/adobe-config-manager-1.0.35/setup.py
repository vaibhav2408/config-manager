# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['adobe_config_mgmt_lib',
 'adobe_config_mgmt_lib.apis',
 'adobe_config_mgmt_lib.core',
 'adobe_config_mgmt_lib.core.cron',
 'adobe_config_mgmt_lib.core.service_config',
 'adobe_config_mgmt_lib.dal',
 'adobe_config_mgmt_lib.dal.dynamodb',
 'adobe_config_mgmt_lib.models',
 'adobe_config_mgmt_lib.models.configs',
 'adobe_config_mgmt_lib.models.generic',
 'adobe_config_mgmt_lib.resources',
 'scripts']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp-retry>=2.4.6,<3.0.0',
 'argparse>=1.4.0,<2.0.0',
 'asyncio>=3.4.3,<4.0.0',
 'boto3>=1.24.11,<2.0.0',
 'botocore>=1.27.11,<2.0.0',
 'cloudevents>=1.2.0,<2.0.0',
 'fastapi>=0.78.0,<0.79.0',
 'mock>=4.0.3,<5.0.0',
 'pydantic[email]>=1.5.1,<2.0.0',
 'requests>=2.23.0,<3.0.0',
 'structlog>=20.2.0,<21.0.0',
 'uvicorn>=0.11.5,<0.12.0']

entry_points = \
{'console_scripts': ['fix-lint = scripts.run:fix_lint',
                     'lint = scripts.run:lint',
                     'run = scripts.run:start',
                     'test = scripts.run:test']}

setup_kwargs = {
    'name': 'adobe-config-manager',
    'version': '1.0.35',
    'description': 'Vaibhav Config Manager lib',
    'long_description': None,
    'author': 'Vaibhav Rai',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
