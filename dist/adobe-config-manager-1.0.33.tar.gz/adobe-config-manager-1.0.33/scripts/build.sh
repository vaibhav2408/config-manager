#!/bin/bash -ex

poetry config http-basic.jfrog $JFROG_USERNAME $JFROG_PASSWORD

poetry install --no-dev

poetry build


#[distutils]
#index-servers = local
#[local]
#repository: https://vaibhavrai46.com/artifactory/api/pypi/pypi-local
#username: admin
#password: AP5D2NKZMuqkSfLESHqcj6RaLrH