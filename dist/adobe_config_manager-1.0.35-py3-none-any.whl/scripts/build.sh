#!/bin/bash -ex

poetry config http-basic.jfrog "admin" "AP5D2NKZMuqkSfLESHqcj6RaLrH"

poetry install --no-dev

poetry build
