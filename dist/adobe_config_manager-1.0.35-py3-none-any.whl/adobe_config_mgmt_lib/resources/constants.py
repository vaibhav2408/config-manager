# Dynamodb Keys
SERVICE_ID_KEY = "service_id"
CONFIG_NAME_KEY = "config_name"
CONFIG_KEY = "config"
CREATED_AT_KEY = "created_at"
UPDATED_AT_KEY = "updated_at"
